### Project 5.03
Modify the `broker.c` program of Section 5.2 by making both of the following
changes:

(a) Ask the user to enter the number of shares and the price per share, instead
of the value of the trade.  
(b) Add statements that compute the commission charged by a rival broker ($33
plus 3 cents per share fewer than 2000 shares; $33 plus 2 cents per share for
2000 shares or more). Display the rival's commission as well as the commission
charged by the original broker.

### Solution
See `3.c`.
