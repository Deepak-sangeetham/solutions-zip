### Project 5.06
Modify the `upc.c` program of Section 4.1 so that it checks whether a UPC is
valid. After the users enters a UPC, the program will display either `VALID` or
`NOT VALID`.

### Solution
See `6.c`.
