### Project 5.09
Write a program that prompts the user to enter two dates and then indicates
which date comes earlier on the calandar:

```
Enter first date (mm/dd/yyyy): 3/6/08
Enter second date (mm/dd/yyyy): 5/17/07
5/17/07 is earlier than 3/6/08
```

### Solution
See `9.c`.
