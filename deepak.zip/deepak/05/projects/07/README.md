### Project 5.07
Write a program that finds the largest and smallest of four integers entered by
the user:

```
Enter four integers: 21 42 10 35
Largest: 43
Smallest: 10
```

Use as few `if` statements as possible: *Hint*: Four `if` statements are
sufficient.

### Solution
See `7.c`.
