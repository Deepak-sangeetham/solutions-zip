### Exercise 5.07
What does the following statement print if `i` has the value 17? What does it
print if `i` has the value -17?

```c
printf("%d\n", i >= 0 ? i : -i);
```

### Solution
The statement will print 17 in both cases.
