### Project 3.01
Write a program that accepts a date from the user in the form *mm/dd/yyy* and
then displays it in the form *yyymmdd*:

```
Enter a date (mm/dd/yyyy): 2/17/2011
You entered the date 20110217
```

### Solution
See `1.c`
