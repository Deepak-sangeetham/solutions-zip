### Project 3.04
Write a program that prompts the user to enter a telephone number in the form
(xxx) xxx-xxxx and then displays the number in the form xxx.xxx.xxxx:

```
Enter phone number [(xxx) xxx-xxxx]: (404) 817-6900
You entered 404.817.6900
```

### Solution
See `4.c`.
