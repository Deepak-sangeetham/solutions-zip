### Project 13.11

Modify Programming Project 13 from Chapter 7 so that it includes the following
function:

```c
double compute_average_word_length(const char *sentence);
```

The function returns the average length of the words in the string pointed to by
`sentence`.

### Solution

See `11.c`.
