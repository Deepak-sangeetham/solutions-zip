### Project 13.14

Modify Programming Project 16 from Chapter 8 so that it includes the following
function:

```c
bool are_anagrams(const char *word1, const char *word2);
```

The function returns `true` if the strings pointed to by `word1` and `word2` are
anagrams.

### Solution

See `14.c`.
