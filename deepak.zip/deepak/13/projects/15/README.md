### Project 13.15

Modify Programming Project 6 from Chapter 10 so that it includes the following
function:

```c
int evaluate_RPN_expression(const char *expression);
```

The function returns the value of the RPN expression pointed to by `expression`.

### Solution

See `15.c`.
