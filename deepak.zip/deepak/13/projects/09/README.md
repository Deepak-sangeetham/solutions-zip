### Project 13.09

Modify Programming Project 10 from Chapter 7 so that it includes the following
function:

```c
int compute_vowel_count(const char *sentence);
```

The function returns the number of vowels in the string pointed to by the
`sentence` parameter.

### Solution
See `9.c`.
