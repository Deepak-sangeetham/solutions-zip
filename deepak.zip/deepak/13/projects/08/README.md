### Project 13.08

Modify Programming Project 5 from Chapter 7 so that it includes the following
function:

```c
int compute_scrabble_value(const char *word);
```

The function returns the SCRABBLE value of the string pointed to by `word`.

### Solution

See `8.c`.
