### Project 13.13

Modify Programming Project 15 from Chapter 8 so that it includes the following
function:

```c
void encrypt(char *message, int shift);
```

The function expects `message` to point to a string containing the message to be
encrypted; `shift` represents the amount by which each letter in the message is
to be shifted.

### Solution

See `13.c`.
