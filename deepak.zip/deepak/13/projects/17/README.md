### Project 13.17

Modify Programming Project 2 from Chapter 12 so that it includes the following
function:

```c
bool is_palindrome(const char *message);
```

The function returns `true` if the string pointed to by `message` is a
palindrome.

### Solution

See `17.c`.
