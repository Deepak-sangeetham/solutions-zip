### Project 13.16

Modify Programming Project 1 from Chapter 12 so that it includes the following
function:

```c
void reverse(char *message);
```

The function reverses the string pointed to by message. *Hint:* Use two
pointers, one initially pointing to the first character of the string and the
other initially pointing to the last character. Have the function reverse these
characters and then move the pointers toward each other, repeating the process
until the pointers meet.

### Solution

See `16.c`.
