### Project 13.03

Modify the `deal.c` program of Section 8.2 so that it prints the full names of
the cards it deals:

```
Enter number of cards in hand: 5
You hand:
Seven of clubs
Two of spades
Five of diamonds
Ace of spades
Two of hearts
```

*Hint*: Replace `rank_code` and `suit_code` by arrays containing pointers to
strings.

### Solution
See `3.c`.
