### Project 13.06

Improve the `planet.c` program of Section 13.7 by having it ignore case when
comparing command-line arguments with strings in the `planets` array.

### Solution

See `6.c`.
