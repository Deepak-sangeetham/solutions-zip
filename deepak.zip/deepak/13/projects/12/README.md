### Project 13.12

Modify Programming Project 14 from Chapter 8 so that it stores the words in a
two-dimensional `char` array as it reads the sentence, with each row of the
array storing a single word. Assume that the sentence contains no more than 30
words and no word is more than 20 characters long. Be sure to store a null
character at the end of each word so that it can be treated as a string.

### Solution

See `12.c`.
