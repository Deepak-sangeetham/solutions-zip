### Project 13.07

Modify Programming Project 11 from Chapter 5 so that it uses arrays containing
pointers to strings instead of `switch` tatements. For example, instead of using
a `switch` statement to print the words for the first digit, use the digit as an
index into an array that contains the strings `"twenty"`, `"thirty"` and so
forth.

### Solution

See `7.c`.
