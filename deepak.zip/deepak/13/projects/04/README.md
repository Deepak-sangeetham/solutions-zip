### Project 13.04

Write a program named `reverse.c` that echoes its command-line arguments in
reverse order. Running the program by typing

```
reverse void and null 
```

should produce the following output:

```
null and void
```

### Solution

See `reverse.c`.
