### Exercise 10.03
Suppose that a program has only one function (`main`). How many different
variables names `i` could this program contain?

### Solution
There is no limit to the number of blocks that can be declared within `main`, so
there is no limmit to the number of `i` variables that the program could
contain. Otherwise, there can be one external variable and one internal variable
named `i`.
