### Project 10.02
Modify the `poker.c` program of Section 10.5 by moving the `num_in_rank` and
`num_in_suit` arrays into `main`, which will pass them as arguments to
`read_cards` and `analyze_hand`.

### Solution
See `2.c`.
