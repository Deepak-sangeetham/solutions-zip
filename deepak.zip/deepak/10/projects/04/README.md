### Project 10.04
Modify the `poker.c` program of Section 10.5 by having it recognize an
additional category, "royal flush" (ace, king, queen, jack, ten of the same
suit). A royal flush ranks higher than all other ranks.

### Solution
See `4.c`.
