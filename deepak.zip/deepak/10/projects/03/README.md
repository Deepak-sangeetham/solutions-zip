### Project 10.03
Remove the `num_in_rank`, `num_in_suit` and `card_exists` arrays from the
`poker.c` program of Section 10.5. Have the program store the cards in a 5 x 2
array instead. Each row of the array will represent a card. For example, if the
array is named `hand`, then `hand[0][0]` will store the rank of the first card
and `hand[0][1]` will store the suit of the first card.

### Solution
See `3.c`.
