### Project 10.05
Modify the `poker.c` program of Section 10.5 by allowing "ace-low" straights
(ace, two, three, four, five).

### Solution
See `5.c`.
