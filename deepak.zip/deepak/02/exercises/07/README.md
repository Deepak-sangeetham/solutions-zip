### Exercise 2.07
Which of the following are keywords in C?

(a) `for`  
(b) `If`  
(c) `main`  
(d) `printf`  
(e) `while`

### Solution
(a) and (e) are keywords. (b) would be a keyword if `If` was written as `if`.
