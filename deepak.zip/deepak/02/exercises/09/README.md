### Exercise 2.09
Insert spaces between the tokens in Exercise 8 to make the statement easier to
read.

### Solution
```c
answer = (3 * q - p * p) / 3;
```
