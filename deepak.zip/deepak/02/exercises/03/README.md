### Exercise 2.03
Condense the `dweight.c` program by (1) replacing the assignments to `height`,
`length`, and `width` with initializers and (2) removing the `weight` variable,
instead calculating `(volume + 165) / 166` within the last `printf`.

### Solution
See `dweight.c`.
