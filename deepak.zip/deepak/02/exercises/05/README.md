### Exercise 2.05
Which of the following are not legal C identifiers?

(a) `100_bottles`  
(b) `_100_bottles`  
(c) `one_hundred_bottles`  
(d) `bottles_by_the_hundred`

### Solution
(a) is not a legal identifier, because identifiers must start with a letter or
underscore.
