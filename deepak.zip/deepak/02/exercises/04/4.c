#include <stdio.h>

int main(void) {

    int a, b, c, d, e;
    float f, g, h, i, j;
    
    printf("%d\n%d\n%d\n%d\n%d\n%f\n%f\n%f\n%f\n%f\n", 
           a, b, c, d, e, f, g, h, i, j);

    return 0;
}
