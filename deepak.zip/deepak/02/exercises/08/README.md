### Exercise 2.08
How many tokens are there in the following statemnt?
```c
answer=(3*q-p*p)/3;
```

### Solution
There are thirteen tokens in the statement, six of which are non-unique.
