### Project 2.03
Modify the program of Programming Project 2 so that it prompts the user to enter
the radius of the sphere.

### Solution
See `3.c`.
