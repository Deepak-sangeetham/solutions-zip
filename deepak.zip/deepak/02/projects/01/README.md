### Project 2.01
Write a program that uses `printf` to display the following picture on the
screen:
```
       *
      *
     *
*   *
 * *
  *
```
### Solution
See `1.c`
