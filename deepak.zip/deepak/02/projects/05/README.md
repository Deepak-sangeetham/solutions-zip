### Project 2.05
Write a program that asks the user to enter a value for x and then displays the
value of the following polynomial:

3x<sup>5</sup> + 2x<sup>4</sup> - 5x<sup>3</sup> - x<sup>2</sup> + 7x - 6

*Hint*: C doesn't have an exponentiation operator, so you'll need to multiply x
by itself repeatedly in order to compute the powers of x. (For example, `x * x *
x` is `x` cubed.)

### Solution
See `5.c`.
