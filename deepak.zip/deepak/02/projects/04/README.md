### Project 2.04
Write a program that asks the user to enter a dollars-and-cents amount, then
displays the amount with a 5% tax added:
```
Enter an amount: 100.00
With tax added: $105.00
```

### Solution
See `4.c`.
