#include <stdio.h>

int main(void) {

    printf("Sphere volume: %.2f cubic meters\n", 4.0f/3.0f * 3.14f * 1000);
    return 0;
}
