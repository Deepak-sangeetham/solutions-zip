### Project 16.04

Modify the `inventory.c` program of Section 16.3 by adding a `price` member to
the `part` structure. The `insert` function should ask the user for the price of
a new item. The `search` and `print` functions should display the price. Add a
new command that allows the user to change the price of a part.

### Solution

See program files.
