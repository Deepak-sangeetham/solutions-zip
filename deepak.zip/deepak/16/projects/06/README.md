### Project 16.06

Modify Programming Project 9 from Chapter 5 so that each date entered by the
user is stored in a `date` structure (see Exercise 5). Incorporate the
`compare_dates` function of Exercise 5 into your program.

### Solution

See `6.c`. 
