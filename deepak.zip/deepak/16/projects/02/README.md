### Project 16.02

Modify the `inventory.c` program of Section 16.3 so that the `p` (print)
operation displays the parts sorted by part number.

### Solution

See program files. NB: `quicksort.c` and `quicksort.h` are copied from
Programming Project 15.03, altered to accept `struct part` instead of `int`.
