### Project 16.05

Modify Programming Project 8 from Chapter 5 so that the times are stored in a
single array. The elements of the array will be structures, each containing a
departure time and the corresponding arrival time (Each time will be an integer,
representing the number of minutes since midnight). The program will use a loop
to search the array for the departure time closest to the time entered by the
user.

### Solution

See `5.c`. 
