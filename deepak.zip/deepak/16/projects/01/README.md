### Project 16.01

Write a program that asks the user to enter an international dialing code and
then looks it up in the `country_codes` array (see Section 16.3). If it finds
the code, the program should display the name of the corresponding country; if
not, the program should print an error message.

### Solution

See `1.c`.
