### Project 16.03

Modify the `inventory.c` program of Section 16.3 by making `inventory` and
`num_parts` local to the `main` function.

### Solution

See program files.
