### Exercise 16.21

What are the integer values of the enumeration constants in each of the
following declarations?

(a) `enum {NUL, SOH, STX, ETX};`  
(b) `enum {VT = 11, FF, CR};`  
(c) `enum {SO = 14, ST, DLE, CAN = 24, EM};`  
(d) `enum {ENQ = 45, ACK, BEL, LF = 37, ETB, ESC};`

### Solution

#### (a)

0, 1, 2 and 3.

#### (b)

11, 12 and 13.

#### (c)

14, 15, 16, 24 and 25.

#### (d)

45, 46, 47, 37, 38 and 39.
