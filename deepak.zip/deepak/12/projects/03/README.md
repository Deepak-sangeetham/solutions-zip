### Project 12.03
Simplify Programming Project 1(b) by taking advantage of the fact that an array
name can be used as a pointer.

### Solution
See `3.c`. NB: My original solution to 1(b) is identical to this one.
