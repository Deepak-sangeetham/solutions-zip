### Project 12.06
Modify the `qsort.c` program of Section 9.6 so that `low`, `high` and `middle`
are pointers to array elements rather than integers. The `split` function will
need to return a pointer, not an integer.

### Solution
See `6.c`.
