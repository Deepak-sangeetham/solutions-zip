### Project 12.07
Modify the `maxmin.c` program of Section 11.4 so that the `max_min` function
uses a pointer instead of an integer to keep track of the current position in
the array.

### Solution
See `7.c`.
