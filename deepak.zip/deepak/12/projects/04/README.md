### Project 12.04
Simplify Programming Project 2(b) by taking advantage of that fact that an array
name can be used as a pointer.

### Solution
See `4.c`. NB: My original solution to 2(b) is identical to this one.
