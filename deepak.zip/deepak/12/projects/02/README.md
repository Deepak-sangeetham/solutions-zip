### Project 12.02
#### (a)
Write a program that reads a message, then checks whether it's a palindrom (the
letters in the message are the same from left to right as from right to left):

```
Enter a message: He lived as a devil, eh?
Palindrome

Enter a message: Madam, I am Adam.
Not a palindrome
```

Ignore all characters that aren't letters. Use integer variables to keep track
of positions in the array.

#### (b)
Revise the program to use pointers instead of integers to keep trac of positions
in the array.

### Solution
See `2.c`.
