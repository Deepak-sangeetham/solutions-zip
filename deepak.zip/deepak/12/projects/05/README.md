### Project 12.05
Modify Programming Project 14 from Chapter 8 so that it uses a pointer instead
of an integer to keep track of the current position in the array that contains
the sentence.

### Solution
See `5.c`.
