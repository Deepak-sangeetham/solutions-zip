### Exercise 7.01
Give the decimal value of each of the following integer constants.

(a) `077`  
(b) `0x77`  
(c) `0XABC`

### Solution

(a) 63  
(b) 119  
(c) 2748
