### Exercise 7.09
Suppose that `i` and `j` are variables of type `int`. What is the type of the
expression `i / j + 'a'`?

### Solution

`int`. The expression automatically promotes the `char` value `'a'` to an `int`.
