### Exercise 7.12
Suppose that `i` is a variable of type `int`, `f` is a variable of type `float`,
and `d` is a varaible of type `double`. Explain what conversions take place
during the execution of the statement:

`d = i + f;`

### Solution

The addition operation will require conversion of the value of `i` to `float`,
and the assignment operation will require conversion of the summed value to
`double`.
