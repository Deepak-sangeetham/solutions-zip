### Exercise 7.11
Suppose that `i` is a variable of type `int`, `f` is a variable of type `float`,
and `d` is a variable of type `double`. What is the type of the expression `i *
f / d`?

### Solution

`double`, as it will promote the other types automatically to `double`.
