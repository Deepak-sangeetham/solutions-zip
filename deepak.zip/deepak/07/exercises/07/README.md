### Exercise 7.07
For each of the following character escapes, give the equivalent octal escape.
(Assume that the character set is ASCII.) You may which to consult Appendix E,
which lists the numerical codes for ASCII characters.

(a) `\b`  
(b) `\n`  
(c) `\r`  
(d) `\t`

### Solution

(a) `\10`  
(b) `\12`  
(c) `\15`  
(d) `\11`
