### Exercise 7.08
Repeat Exercise 7, but give the equivalent hexadecimal escape.

### Solution

(a) `\x08`  
(b) `\x0a`  
(c) `\x0d`  
(d) `\x09`
