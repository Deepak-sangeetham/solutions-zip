### Project 7.10
Write a program that counts the number of vowels (a, e, i, o and u) in a
sentence:

```
Enter a sentence: And that's the way it is.
Your sentence contains 6 vowels.
```

### Solution
See `10.c`.
