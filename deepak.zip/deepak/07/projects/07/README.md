### Project 7.07
Modify Programming Project 6 from Chapter 3 so that the user may add, subtract,
multiply or divide two fractions (by entering either +, -, * or / between the
fractions).

### Solution
See `7.c`.
