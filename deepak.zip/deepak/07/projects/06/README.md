### Project 7.06
Write a program that prints the values of `sizeof(int)`, `sizeof(short)`,
`sizeof(long)`, `sizeof(float)`, `sizeof(double)` and `sizeof(long double)`.

### Solution
See `6.c`.
