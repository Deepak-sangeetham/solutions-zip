### Project 7.03
Modify the `sum2.c` program of Section 7.1 to sum a series of `double` values.

### Solution
See `3.c`.
