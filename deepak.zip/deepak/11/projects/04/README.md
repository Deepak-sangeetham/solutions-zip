### Project 11.04
Modify the `poker.c` program of Section 10.5 by moving all external variables
into `main` and modifying functions so that they communicate by passing
arguments. The `analyze_hand` function needs to change the `straight`, `flush`,
`four`, `three` and `pairs` variables, so it will have to be passed pointers to
those variables.

### Solution
See `4.c`.
