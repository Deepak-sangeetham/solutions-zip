### Project 11.03
Modify Programming Project 3 from Chapter 6 so that it includes the following
function:

```c
void reduce(int numerator, int denominator,
            int *reduced_numerator, int *reduced_denominator);
```

`numerator` and `denominator` are the numerator and denominator of a fraction.
`reduced_numerator` and `reduced_denominator` are pointers to variables in which
the function will store the numerator and denominator of the fraction once it
has been reduced to lowest terms.

### Solution
See `3.c`.
