### Exercise 11.02
If `i` is an `int` variable and `p` and `q` are pointers to `int`, which of the
following assignments are legal?

(a) `p = i;`    (d) `p = &q;`   (g) `p = *q;`  
(b) `*p = &i;`  (e) `p = *&q;`  (h) `*p = q;`  
(c) `&p = q;`   (f) `p = q;`    (i) `*p = *q;`

### Solution
(e), (f) and (i) are legal statements.
