### Exercise 8.03
Write a declaration of an array named `weekend` containing seven `bool` values.
Include an initializer that makes the first and last values `true`; all other
values should be `false`;

### Solution

```c
int weekend[7] = {1, 0, 0, 0, 0, 0, 1};
```
