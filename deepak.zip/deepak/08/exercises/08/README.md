### Exercise 8.08
Write a declaration for a two-dimensional array named `temperature_readings`
that stores one month of hourly temperature readings. (For simplicity, assume
that a month has 30 days.) The rows of the array should represent days of the
month; the colums should represent hours of the day.

### Solution

```c
double temperature_readings[30][24] = {0};
```
