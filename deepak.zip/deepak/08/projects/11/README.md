### Project 8.11
Modify Programming Project 4 from Chapter 7 so that the program labels its
output:

```
Enter phone number: 1-800-COL-LECT
In numeric form: 1-800-265-5328
```

The program will need to store the phone number (either in its original form or
in its numeric form) in an array of character until it can be printed. You may
assume that the phone number is no more than 15 characters long.

### Solution
See `11.c`.
