### Project 8.08
Modify Programming Project 7 so that it prompts for five quiz grades for each of
five students, then computes the total score and average score for each student,
and the average score, high score, and low score for each quiz.

### Solution
See `8.c`.
