### Project 8.12
Modify Programming Project 5 from Chapter 7 so that the SCRABBLE values of the
letters are stored in an array. The array wil have 26 elements, corresponding to
the 26 letters of the alphabet. For example, element 0 of the array will store 1
(because the SCRABBLE value of the letter B is 3), and so forth. As each
character of the input word is read, the program will use the array to determine
the SCRABBLE value of that character. Use an array initializer to set up the
array.

### Solution
See `12.c`.
