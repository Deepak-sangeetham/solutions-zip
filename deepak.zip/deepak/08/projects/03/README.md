### Project 8.03
Modify the `repdigit.c` program of Section 8.1 so that the user can enter more
than one number to be tested for repeated digits. The program should terminate
when the user enters a number that's less than or equal to 0.

### Solution
See `3.c`.
