### Project 8.01
Modify the `repdigit.c` program of Section 8.1 so that it shows which digits (if
any) were repeated:

```
Enter a number: 939577
Repeated digit(s): 7 9
```

### Solution
See `1.c`.
