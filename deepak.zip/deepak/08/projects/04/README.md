### Project 8.04
Modify the `reverse.c` program of Section 8.1 to use the expression `(int)
(sizeof(a) / sizeof(a[0]))` (or a macro with this value for the array length.

### Solution
See `4.c`.
