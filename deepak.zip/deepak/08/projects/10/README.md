### Project 8.10
Modify Programming Project 8 from Chapter 5 so that the departure times are
stored in an array and the arrival times are stored in a second array. (The
times are integers, representing the number of minutes since midnight.) The
program will use a loop to search the array of departure times for the one
closest to the time entered by the user.

### Solution
See `10.c`.
