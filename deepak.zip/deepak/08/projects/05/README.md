### Project 8.05
Modify the `interest.c` program of Section 8.1 so that it compound interest
monthly instead of annually. The form of the output shouldn't change: the
balance should still be shown at annual intervals.

### Solution
See `5.c`.
