### Project 15.03

Modify the `qsort.c` program of Section 9.6 so that the `quicksort` and `split`
functions are in a separate file named `quicksort.c`. Create a header file named
`quicksort.h` that contains prototypes for the two functions and have both
`qsort.c` and `quicksort.c` include this file.

### Solution

See program files.
