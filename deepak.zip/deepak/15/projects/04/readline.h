#ifndef READLINE_H
#define READLINE_H

int read_line(char str[], int n);

#endif
