### Project 15.04

Modify the `remind.c` program of Section 13.5 so that the `read_line` function
is in a separate file named `readline.c`. Create a header file named
`readline.h` that contains a prototype for the function and have both `remind.c`
and `readline.c` include this file.

### Solution

See project files.
