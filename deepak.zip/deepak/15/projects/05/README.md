### Project 15.05

Modify Programming Project 6 from Chapter 10 so that it has separate `stack.h`
and `stack.c` files, as described in Section 15.2.

### Solution

See program files.
