### Exercise 15.02

Which of the following should *not* be put into a header file? Why not?

(a) Function prototypes  
(b) Function definitions  
(c) Macro definitions  
(d) Type definitions

### Solution

Function definitions should not be included in a header file because it would
potentially define individual functions multiple times.
