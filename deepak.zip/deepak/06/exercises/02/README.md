### Exercise 6.02
What output does the following program fragment produce?

```c
i = 9384;
do {
    printf("%d ", i);
    i /= 10;
} while (i > 0);
```

### Solution

`9384 938 93 9 `
