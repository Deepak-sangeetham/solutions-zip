### Exercise 6.07
Translate the program fragment of Exercise 2 into a single `for` statement.

### Solution

```c
for (i = 9384; i > 0; i /= 10)
    printf("%d ", i);
```
