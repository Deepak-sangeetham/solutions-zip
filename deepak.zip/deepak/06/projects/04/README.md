### Project 6.04
Add a loop to the `broker.c` program of Section 5.2 so that the user can enter
more than one trade and the program will caluclate the commission on each. The
program should terminate when the user enters `0` as the trade value:

```
Enter value of trade: 30000
Commission: $166.00

Enter value of trade: 20000
Commission: $144.00

Enter value of trade: 0
```

### Solution
See `4.c`.
