### Project 6.12
Modify Programming Project 11 so that the program continues adding terms until
the current term becomes less than epsilon, where epsilon is a small
(floating-point) number entered by the user.

### Solution
See `12.c`.
