### Project 6.07
Rearrange the `square3.c` program so that the `for` loop initializes `i`, tests
`i`, and increments `i`. Don't rewrite the program; in particular, don't use any
multiplications.

### Solution
See `7.c`.
