### Project 6.09
Programming Project 8 in Chapter 2 asked you to write a program that calculates
the remaining balance on a loan after the first, second, and third monthly
payments. Modify the program so that it also asks the user to enter the number
of payments and then displays the balance remaining after each of these
payments.

### Solution
See `9.c`.
