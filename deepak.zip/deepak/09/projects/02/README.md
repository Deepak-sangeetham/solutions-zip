### Project 9.02
Modify Programming Project 5 from Chapter 5 so that it uses a function to
compute the amount of income tax. When passed an amount of taxable income, the
function will return the tax due.

### Solution
See `2.c`.
