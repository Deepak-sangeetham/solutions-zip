### Project 9.06
Write a function that computes the value of the following polynomial:

3*x*<sup>5</sup> + 2*x*<sup>4</sup> - 5*x*<sup>3</sup> - *x*² + 7x - 6.

Write a program that asks the user to enter a value for *x*, calls the function
to compute the value of the polynomial, and then displays the value returned by
the function.

### Solution
See `6.c`.
