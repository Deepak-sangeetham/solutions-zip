### Project 9.03
Modify Programming Project 9 from Chapter 8 so that it includes the following
functions:

```c
void generate_random_walk(char walk[10][10]);
void print_array(char walk[10][10]);
```

`main` first calls `generate_random_walk`, which initializes the array to
contain `'.'` characters and then replaces some of these characters by the
letters `A` through `Z`, as described in the original project. `main` then calls
`print_array` to display the array on the screen.

### Solution
See `3.c`.
