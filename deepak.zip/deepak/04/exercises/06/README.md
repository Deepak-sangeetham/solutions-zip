### Exercise 4.06
Repeat Exercise 5 for C99.

### Solution

(a) 1  
(b) -3  
(c) 3  
(d) -3
