### Exercise 4.04
Repeat Exercise 3 for C99.

### Solution

(a) 1  
(b) -1  
(c) -1  
(d) 1
