### Project 4.02
Extend the program in Programming Project 1 to handle *three*-digit numbers.

### Solution
See `2.c`.
