### Project 4.05
Rewrite the `upc.c` program of Section 4.1 so that the user enters 11 digits at
one time, instead of entering one digit, then five digits, and then another five
digits.

```
Enter the first 11 digits of a UPC: 01380015173
Check digit: 5
```

### Solution
See `5.c`.
